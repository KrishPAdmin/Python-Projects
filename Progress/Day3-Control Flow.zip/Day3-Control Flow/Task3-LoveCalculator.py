# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!\n")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
nameA = name1.lower()
nameB = name2.lower()
t = 0
r = 0
u = 0
e = 0
l = 0
o = 0
v = 0

t+=(nameA.count('t') + nameB.count('t'))
r+=(nameA.count('r') + nameB.count('r'))
u+=(nameA.count('u') + nameB.count('u'))
e+=(nameA.count('e') + nameB.count('e'))
l+=(nameA.count('l') + nameB.count('l'))
o+=(nameA.count('o') + nameB.count('o'))
v+=(nameA.count('v') + nameB.count('v'))

sumTrue = t+r+u+e
sumLove = l+o+v+e

sum = sumTrue*10 + sumLove

if sum<10 and sum>90:
    print("Your score is " + str(sum) + ", you go together like coke and mentos.")

elif 50>sum>40:
    print("Your score is " + str(sum) + ", you are alright together.")

else:
    print("Your score is " + str(sum))
