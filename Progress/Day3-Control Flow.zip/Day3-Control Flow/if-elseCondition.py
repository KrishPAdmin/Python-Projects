print("Welcome to the Rollercoaster!!!")
height = int(input("\nWhat is your height in cm: "))

if height>120:
    print("You may enter")

else:
    print("You are too short")