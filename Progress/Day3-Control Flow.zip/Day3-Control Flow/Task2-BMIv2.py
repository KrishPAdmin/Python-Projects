# 🚨 Don't change the code below 👇
height = float(input("enter your height in m: "))
weight = float(input("enter your weight in kg: "))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
bmi = int(weight)/(int(height) ** 2)

print("Your BMI is: " + str(bmi))

if(bmi<18.5):
    print("You are underweight")
elif(bmi<25):
    print("You are normal weight")
elif(bmi<30):
    print("You are slightly overweigth")
elif(bmi>=30):
    print("You are overweight")