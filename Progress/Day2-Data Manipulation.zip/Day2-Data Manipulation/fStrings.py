score = 0
height = 1.8
isWinning = False

print(f"your score is {score}, your height is {height}, and you are winning is: {isWinning}")