# 🚨 Don't change the code below 👇
two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇

strTwoDigNum = str(two_digit_number)
intTwoDigNumONE = int(strTwoDigNum[0])
intTwoDigNumTWO = int(strTwoDigNum[1])
sum = intTwoDigNumONE+intTwoDigNumTWO
final = str(sum)

print(strTwoDigNum[0] + " + " +strTwoDigNum[1] + " = " + final)