# 🚨 Don't change the code below 👇
age = input("What is your current age? ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
newAge = 90-int(age)

months = 12*newAge
weeks = 52*newAge
days = 7*weeks

print(f"You have {days} days, {weeks} weeks, and {months} months left.")