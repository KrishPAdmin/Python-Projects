numChar = len(input("What is your name?\n"))

#use a type check funciton to test the type of a variable
# print(type(len(input("What is your name?"))))

newNumChar = str(numChar)

print("Your name has " + newNumChar + " characters.")
float(newNumChar)