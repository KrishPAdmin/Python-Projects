print("Welcome to the tip calculator!")

bill = input("\nWhat was the total bill: $")
tip = input("What percent is the Tip(%): ")
ppl = input("How many people will split the bill: ")

newBill = float(bill)*(int(tip)/100 + 1)
newBill /= int(ppl)

print("Each person should pay: $" + str(round(newBill,2)))