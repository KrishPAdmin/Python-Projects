weight = input("Enter your weight: ")
height = input("Enter your height: ")

bmi = int(weight)/(int(height) ** 2)

print("Your BMI is: " + str(bmi))