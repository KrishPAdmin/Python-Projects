3+5
7-3
3*2
6/3

print(2 ** 3) #exponent 2 to the power 3
print(3/3-3/3+3)

#manipulation of numbers
print(round(12/7, 2))

result = 2
