#Data Types

#Strings:
print("hello"[3]) #or
"hello"[4]
print("123"+"345")

#Integers:
print(123+345)
123_456_789 #use underscore to replace commas in large numbers

#Doubles/Floats:
pi = 3.1415
print(pi)

#Boolean
True 
False