import random

x = random.randint(0,1)
if x == 0:
    print("Heads")
if x == 1:
    print("Tails")