import random

randInt = random.randint(1,10)

print(randInt)

randFloat = random.random()
print(randFloat)
print(int(randFloat*5))#for num from 0-5