#data structure kind of like ARRAYS
nums = [1, 5]

#nested Lists

fruits = []
veges = []

dirtyDozen = [fruits, veges]