import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

rand = random.randint(0,2)

if rand == 0:
    selection = rock
elif rand == 1:
    selection = paper
elif rand == 2:
    selection = scissors

uin = input("Enter your choice for RPS: ")
uin = uin.lower()

if uin == "rock":
    uselection = rock
elif uin == "paper":
    uselection = paper
elif uin == "scissors":
    uselection = scissors

print("Computer chose:")
print(selection)

print("You chose: ")
print(uselection)


if (uselection == rock and selection == rock) or (uselection == scissors and selection == scissors) or (uselection == paper and selection == paper):
    print("TIE")

elif (uselection == rock and selection == scissors) or (uselection == scissors and selection == paper) or (uselection == paper and selection == rock):
    print("You Win!!")
    
elif (uselection == rock and selection == paper) or (uselection == scissors and selection == rock) or (uselection == paper and selection == scissors):
    print("You Lose :(")
