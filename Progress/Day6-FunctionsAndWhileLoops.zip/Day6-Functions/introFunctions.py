#use 'def' to define a function

def greet():
    print("hello")
    print("cyaa")

greet()