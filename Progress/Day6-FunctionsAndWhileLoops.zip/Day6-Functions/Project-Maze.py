#follow right side of the maze till exit

