import random

wordList = ["ardvark", "baboon", "camel"]
word = random.choice(wordList)

guess = (input("Guess a character that is possibly in this word: ")).lower()

for i in range(0,len(word)):
    if(guess == word[i]):
        print("You guessed correctly!")
    else:
        print("Your guess was incorrectly!")