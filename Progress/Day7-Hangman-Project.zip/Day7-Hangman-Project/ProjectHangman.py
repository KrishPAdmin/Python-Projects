import random
import ProjectHangmanWords
import ProjectHangmanArt

# wordList = ["ardvark", "baboon", "camel"]
word = random.choice(ProjectHangmanWords.wordList)
print(word)
List = []
for i in word:
  List += "_"

lives = 6

print(List)
EOG = False #End Of Game

while EOG is False :
    guess = (input("Guess a character that is possibly in this word: ")).lower()
    test = False
    for i in range(0, len(word)):
      if guess == word[i]:
        List[i] = guess
        test = True

    if test is False:
      lives -=1
    test = False
    print(List)
    print(ProjectHangmanArt.stage[lives])
    
    
    
    if '_' not in List:
      EOG is True
      print("You got the correct word :) " + word)
      exit()

    elif lives is 0:
      EOG is True
      print("Sorry but you ran out of lives :( \nThe word was: " + word)
      exit()

    elif '_' in List:
      print("Keep going you got this.")
    
    
      



