import random

wordList = ["ardvark", "baboon", "camel"]
word = random.choice(wordList)

List = []
for i in word:
    List += "_"

print(List)

while List != word:
    guess = (input("Guess a character that is possibly in this word: ")).lower()
    for i in range(len(word)):
        if guess == word[i]:
            List[i] = guess
            print(List)
        else:
            continue



