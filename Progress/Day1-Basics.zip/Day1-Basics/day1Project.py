print("Welcome to the Band Name Generator.")
city = input("What is the name of the ciry you grew up in?\n")

petName = input("What is the name of your pet?\n")

print("Your band name could be: " + city + " " + petName)
