print("What is your name?")
alpha = input()
print("Nice to meet you " + alpha)

print("\n-----------\n")
#or

print("Nice to meet you " + input("What is your name?\n"))
#notice how both methods work in the same way